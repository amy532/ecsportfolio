// amy | turtle crossing |april 15 
int score, health,lives;
boolean play = false;
int x= 75, y= 250;
PImage turtle1;
log log1,log2;



void setup(){
  
size(500,600);
background(#72CAF5);
score= 0;
health= 100;
lives = 3;
turtle1= loadImage("turtle.png");
log1 = new log(150);
log2 = new log(200);

}

void draw() {
  if (play == false) {
    startScreen();
  } else {
background(#7ACFF7);
drawBackground();
infoPanel();
image(turtle1,x,y);
log1.display();
log1.move();
log2.display();
log2.move();
    }
 }

void keyPressed() {
if(key == CODED) {
 if(keyCode == RIGHT) {
   x = x + 24;
 }else if(keyCode == LEFT){
   x=x - 24;
   }else if(keyCode == UP){
    y= y - 24;
    }else if(keyCode == DOWN){
   y = y +24;
   }
  }
}

void drawBackground() {
fill(#D8BF8C);
rect(0,40,width,100);


} 

void startScreen() {
background(0);
fill(255);
textAlign(CENTER);
textSize(30);
text("welcome to Turtle Game",width/2,height/2-40);
text("by Amy Gonzalez",width/2,height/2);
text("press space to start game",width/2,height/2+40);
if(keyPressed && key == ' ') {
play = true;
loop();
  }
} 

void gameOver() {
background(0);
fill(255);
textAlign(CENTER);
text("GAME OVER!",width/2,height/2);


} 

void infoPanel() {
  fill(#E3F2FA);
rect(0,0,width,40);
fill(0);
textSize(32);
textAlign(CENTER);
text("Score:"+ score,width/5,35);
text("Lives:" + lives,width-100,35);
} 
