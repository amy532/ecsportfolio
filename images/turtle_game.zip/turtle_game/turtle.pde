class Turtle {
  // member variables
  int x, y, w, h;
PImage f1;

  //constructor
  Turtle () {
    x=100;
    y=100;
    w=50;
    h=50;
f1= loadImage("turtle.png");
f1.resize(w,h);

  }
  // member methods
  void display () {
    imageMode (CENTER);
    image(f1,x,y);
  }
   }  
