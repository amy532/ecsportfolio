class log {
// Member Variables
int x, y, w, h,speed;
PImage l1;
void draw() {
  background(#FF72CAF5);
  log1.move();
  log1.display();
  
  log2.move();
  log2.display();
}
  

// constructor
log(int y){
  x = -50;
  this.y = y;
  w = 50;
  h = 50;
  speed = int(random(1,5));
  l1 = loadImage( "log.png");
}

void display() {
  imageMode(CENTER);
  l1.resize(w,h);
  image(l1,x,y);
}

void move() {
  x += speed;
  if (x > width + w){
    x = -w;
    speed = int(random(1,5));
    
    }
  }
}
  
